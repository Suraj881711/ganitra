# 💻 Laptop Price Prediction

A Flask web app that predicts a laptop's price (₹) from its specifications
using a Linear Regression model trained on 800+ laptop listings.

## What it does

Choose the laptop's brand, processor brand/name/generation, RAM, SSD, HDD,
OS, OS bit, graphics card, warranty, MS Office and rating (plus the
listing's number of ratings/reviews), and the app predicts the price,
echoes the chosen specification, and keeps a history of your predictions
for the session.

## ⚠️ Important fixes in this version

1. **The form now matches the model.** The original app asked for weight,
   touchscreen and screen size (which the trained model never saw), used
   hand-written encoding dictionaries that didn't match the training
   encodings, and passed the features in the wrong order — so it was not
   really using the trained model. The form now collects the model's exact
   15 features, encoded with the same LabelEncoder scheme as the training
   notebook (`task1.ipynb`).
2. **Prediction crash fixed** — the model returns a 2-D prediction (it
   was trained against a one-column DataFrame); the app now handles it.
3. **Missing pages created** — the navbar linked to `/contact` and
   `/history`, which didn't exist; both pages now work.

## Verified model performance

- **Test R² = 0.54** (Linear Regression, 80/20 train–test split,
  `random_state=42`, reproduced from `laptop_price_ml.ipynb` and
  confirmed identical for the saved model). Predictions are rough
  estimates — Linear Regression on label-encoded categories is a simple
  baseline, and the README states this honestly rather than inflating it.

## Tech stack

- Python, Flask
- scikit-learn (LinearRegression, LabelEncoder), pandas, NumPy, joblib

## How to run

```bash
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000 and go to **Predict**.

## Files

- `app.py` — Flask routes (`/`, `/project`, `/about`, `/contact`,
  `/history`, `/health`)
- `ml_laptop_Price.lb` — trained Linear Regression model
- `laptop_price_ml.ipynb` — model training notebook (Linear Regression,
  plus SVR/KNN experiments)
- `task1.ipynb` — data cleaning/encoding notebook
- `laptopPrice.csv` — raw dataset (823 listings)
- `Cleaned_laptop_Price.csv` — cleaned dataset (string values)
- `new_Cleaned_laptop_Price.csv` — encoded dataset used for training

## Dataset note

Laptop listings with brand/processor/storage/OS/warranty details and
prices in ₹. Note the model also uses the listing's number of ratings and
reviews as inputs, exactly as trained.
