import os

import joblib
import numpy as np
import pandas as pd
from flask import Flask, render_template, request, session
from sklearn.preprocessing import LabelEncoder

app = Flask(__name__)
app.secret_key = 'laptop-price-predictor'

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
model = joblib.load(os.path.join(BASE_DIR, 'ml_laptop_Price.lb'))

# The exact features (and order) the saved model was trained on.
FEATURES = ['brand', 'processor_brand', 'processor', 'processor_gnrtn',
            'ram', 'ssd', 'hdd', 'os', 'os_bit', 'graphic_card_gb',
            'warranty', 'msoffice', 'rating',
            'Number of Ratings', 'Number of Reviews']
NUMERIC_FEATURES = ['Number of Ratings', 'Number of Reviews']
CATEGORICAL_FEATURES = [f for f in FEATURES if f not in NUMERIC_FEATURES]

# Rebuild the label encodings exactly as task1.ipynb created them:
# a LabelEncoder fitted on each categorical column of the cleaned
# (string) dataset. The previous app used hand-written encoding
# dictionaries and a different feature order (it even asked for weight,
# touchscreen and screen size, which the model never saw), so its
# predictions did not correspond to the trained model at all.
_clean = pd.read_csv(os.path.join(BASE_DIR, 'Cleaned_laptop_Price.csv'))
ENCODERS = {}
for col in CATEGORICAL_FEATURES:
    le = LabelEncoder()
    le.fit(_clean[col].astype(str))
    ENCODERS[col] = le

LABELS = {
    'brand': 'Brand', 'processor_brand': 'Processor Brand',
    'processor': 'Processor Name', 'processor_gnrtn': 'Processor Generation',
    'ram': 'RAM', 'ssd': 'SSD', 'hdd': 'HDD', 'os': 'Operating System',
    'os_bit': 'OS Bit', 'graphic_card_gb': 'Graphics Card',
    'warranty': 'Warranty', 'msoffice': 'MS Office', 'rating': 'Rating',
    'Number of Ratings': 'Number of Ratings',
    'Number of Reviews': 'Number of Reviews',
}


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/contact')
def contact():
    return render_template('contact.html')


@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/health')
def health():
    return {'status': 'ok'}


@app.route('/history')
def history():
    return render_template('history.html', entries=session.get('history', []))


@app.route('/project', methods=['POST', 'GET'])
def predict():
    options = {col: list(ENCODERS[col].classes_) for col in CATEGORICAL_FEATURES}

    if request.method == 'POST':
        try:
            vector = []
            chosen = {}
            for col in FEATURES:
                raw = request.form[col]
                if col in NUMERIC_FEATURES:
                    value = int(raw)
                    if value < 0:
                        raise ValueError(col)
                    vector.append(value)
                    chosen[col] = value
                else:
                    vector.append(int(ENCODERS[col].transform([raw])[0]))
                    chosen[col] = raw
        except (KeyError, ValueError):
            return render_template(
                'project.html', options=options,
                prediction=None,
                error='⚠️ Invalid input — please choose a value for every field.')

        pred_value = round(
            float(np.asarray(model.predict([vector])).ravel()[0]), 2)

        entries = session.get('history', [])
        entries.insert(0, {'specs': chosen, 'price': pred_value})
        session['history'] = entries[:10]

        return render_template(
            'project.html', options=options,
            prediction=f'{pred_value:,.2f}', chosen=chosen)

    return render_template('project.html', options=options, prediction=None)


if __name__ == '__main__':
    app.run(debug=True)
